var servForm = document.querySelector('form#servform')
servForm.inputs = {} = document.querySelectorAll('div.input-group')
servForm.addons = {} = document.querySelectorAll('span.input-group-addon')
servForm.addons[0].style.background = '#379746'


